// Package upgrade
//
// Dummy to ensure package can be loaded
//
// This file is to avoid the following error:
// can't load package: package go-sqlite3/upgrade: build constraints exclude all Go files in go-sqlite3\upgrade
package upgrade
